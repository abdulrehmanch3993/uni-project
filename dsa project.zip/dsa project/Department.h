#ifndef DEPARTMENT_H
#define DEPARTMENT_H
#include "Course.h"
#include <vector>
using namespace std;

class Department {
public:
    char name[50];
    vector<Course*> courses;

    Department(const char* n);
    void addCourse(Course* c);
    void showCourses();
};

#endif

