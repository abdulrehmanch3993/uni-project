#ifndef UNIVERSITY_H
#define UNIVERSITY_H
#include "Faculty.h"
#include "Student.h"
#include "Course.h"
#include <list>
#include <vector>
using namespace std;

class University {
public:
    list<Student*> students; // Linked list
    vector<Faculty*> faculties; // Tree structure

    void addStudent();
    void addFaculty();
    void addDepartmentToFaculty();
    void addCourseToDepartment();
    void registerStudentToCourse();
    void showStudentTimetable();
    void showCourseInfo();
    void generateReports();
    void showTimetableGUI(int studentID);
    void saveData();
    void loadData();
};

#endif

