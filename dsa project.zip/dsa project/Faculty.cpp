#include "Faculty.h"
#include <iostream>
#include <cstring>
using namespace std;

Faculty::Faculty(const char* n) {
    strcpy(name, n);
}

void Faculty::addDepartment(Department* d) {
    departments.push_back(d);
}

void Faculty::showDepartments() {
    cout << "\nFaculty: " << name << "\nDepartments:\n";
    for (int i = 0; i < departments.size(); i++) {
        cout << " - " << departments[i]->name << "\n";
    }
}

