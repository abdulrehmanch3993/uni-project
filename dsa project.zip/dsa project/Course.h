#ifndef COURSE_H
#define COURSE_H
#include "Student.h"
#include <vector>
#include <queue>
using namespace std;

class Student; // Forward declaration

class Course {
public:
    char name[50];
    char code[20];
    int maxCapacity;
    char time[20];  // Time slot for timetable
    vector<Student*> registered;
    queue<Student*> waitingList;

    Course(const char* n, const char* c, int cap, const char* t);
    bool addStudent(Student* s);
    void removeStudent(Student* s);
    void showRegistered();
};

#endif


