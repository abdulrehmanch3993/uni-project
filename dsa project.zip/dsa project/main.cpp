#include "University.h"
#include <iostream>
using namespace std;

int main() {
    University uni;
    uni.loadData();

    int choice;
    do {
        cout << "\n--- University Course Registration System ---\n";
        cout << "1. Add Student\n2. Add Faculty\n3. Add Department\n4. Add Course\n";
        cout << "5. Register Student to Course\n6. Show Student Timetable\n";
        cout << "7. Show Course Info\n8. Generate Reports\n9. Show Timetable GUI\n10. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch(choice) {
            case 1: uni.addStudent(); break;
            case 2: uni.addFaculty(); break;
            case 3: uni.addDepartmentToFaculty(); break;
            case 4: uni.addCourseToDepartment(); break;
            case 5: uni.registerStudentToCourse(); break;
            case 6: uni.showStudentTimetable(); break;
            case 7: uni.showCourseInfo(); break;
            case 8: uni.generateReports(); break;
            case 9: {
                int sid;
                cout << "Enter student ID: ";
                cin >> sid;
                uni.showTimetableGUI(sid);
                break;
            }
            case 10: uni.saveData(); cout << "Exiting...\n"; break;
            default: cout << "Invalid choice!\n";
        }
    } while(choice != 10);

    return 0;
}

