#ifndef STUDENT_H
#define STUDENT_H
#include "Course.h"
#include <list>
using namespace std;

class Course; // Forward declaration

class Student {
public:
    char name[50];
    int id;
    list<Course*> enrolledCourses; // Linked list of courses

    Student(const char* n, int i);
    void registerCourse(Course* c);
    void dropCourse(Course* c);
    void showCourses();
};

#endif

