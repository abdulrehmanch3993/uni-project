#include "Student.h"
#include "Course.h"
#include <iostream>
#include <cstring>
using namespace std;

Student::Student(const char* n, int i) {
    id = i;
    strcpy(name, n);
}

void Student::registerCourse(Course* c) {
    enrolledCourses.push_back(c);
}

void Student::dropCourse(Course* c) {
    enrolledCourses.remove(c);
}

void Student::showCourses() {
    cout << "\nStudent: " << name << " (ID: " << id << ")\nEnrolled Courses:\n";
    if (enrolledCourses.empty()) {
        cout << "None\n";
        return;
    }
    for (list<Course*>::iterator it = enrolledCourses.begin(); it != enrolledCourses.end(); ++it) {
        Course* c = *it;
        cout << " - " << c->name << " (" << c->code << ") at " << c->time << "\n";
    }
}

