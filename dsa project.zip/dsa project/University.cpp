#include "University.h"
#include "Faculty.h"
#include "Department.h"
#include "Course.h"
#include "Student.h"
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

// Add Student
void University::addStudent() {
    int id;
    char name[50];
    cout << "Enter student ID: ";
    cin >> id;
    cin.ignore();
    cout << "Enter student name: ";
    cin.getline(name, 50);
    students.push_back(new Student(name, id));
    cout << "Student added!\n";
}

// Add Faculty
void University::addFaculty() {
    char fname[50];
    cout << "Enter faculty name: ";
    cin.ignore();
    cin.getline(fname, 50);
    faculties.push_back(new Faculty(fname));
    cout << "Faculty added!\n";
}

// Add Department
void University::addDepartmentToFaculty() {
    char fname[50], dname[50];
    cout << "Enter faculty name: ";
    cin.ignore();
    cin.getline(fname, 50);
    Faculty* f = NULL;
    for (int i = 0; i < faculties.size(); i++)
        if (strcmp(faculties[i]->name, fname) == 0) { f = faculties[i]; break; }
    if (f == NULL) { cout << "Faculty not found.\n"; return; }

    cout << "Enter department name: ";
    cin.getline(dname, 50);
    f->addDepartment(new Department(dname));
    cout << "Department added.\n";
}

// Add Course
void University::addCourseToDepartment() {
    char fname[50], dname[50], cname[50], ccode[20], ctime[20];
    int cap;

    cout << "Enter faculty name: ";
    cin.ignore();
    cin.getline(fname, 50);
    Faculty* f = NULL;
    for (int i = 0; i < faculties.size(); i++)
        if (strcmp(faculties[i]->name, fname) == 0) { f = faculties[i]; break; }
    if (f == NULL) { cout << "Faculty not found.\n"; return; }

    cout << "Enter department name: ";
    cin.getline(dname, 50);
    Department* d = NULL;
    for (int i = 0; i < f->departments.size(); i++)
        if (strcmp(f->departments[i]->name, dname) == 0) { d = f->departments[i]; break; }
    if (d == NULL) { cout << "Department not found.\n"; return; }

    cout << "Enter course name: ";
    cin.getline(cname, 50);
    cout << "Enter course code: ";
    cin.getline(ccode, 20);
    cout << "Enter course capacity: ";
    cin >> cap;
    cin.ignore();
    cout << "Enter course time (e.g., Mon 9AM): ";
    cin.getline(ctime, 20);

    d->addCourse(new Course(cname, ccode, cap, ctime));
    cout << "Course added to department.\n";
}

// Register student
void University::registerStudentToCourse() {
    int sid;
    char ccode[20];
    cout << "Enter student ID: ";
    cin >> sid;
    cin.ignore();
    cout << "Enter course code: ";
    cin.getline(ccode, 20);

    Student* st = NULL;
    for (list<Student*>::iterator it = students.begin(); it != students.end(); ++it)
        if ((*it)->id == sid) { st = *it; break; }

    Course* cr = NULL;
    for (int i = 0; i < faculties.size(); i++)
        for (int j = 0; j < faculties[i]->departments.size(); j++)
            for (int k = 0; k < faculties[i]->departments[j]->courses.size(); k++)
                if (strcmp(faculties[i]->departments[j]->courses[k]->code, ccode) == 0) {
                    cr = faculties[i]->departments[j]->courses[k];
                    break;
                }

    if (st != NULL && cr != NULL) {
        bool success = cr->addStudent(st);
        if (success) st->registerCourse(cr);
        cout << (success ? "Registration successful!\n" : "Course full! Added to waiting list.\n");
    } else cout << "Student or course not found.\n";
}

// Show Student Timetable
void University::showStudentTimetable() {
    int sid;
    cout << "Enter student ID: ";
    cin >> sid;
    Student* st = NULL;
    for (list<Student*>::iterator it = students.begin(); it != students.end(); ++it)
        if ((*it)->id == sid) { st = *it; break; }
    if (st != NULL) st->showCourses();
    else cout << "Student not found.\n";
}

// Show Course Info
void University::showCourseInfo() {
    char ccode[20];
    cout << "Enter course code: ";
    cin.ignore();
    cin.getline(ccode, 20);

    Course* cr = NULL;
    for (int i = 0; i < faculties.size(); i++)
        for (int j = 0; j < faculties[i]->departments.size(); j++)
            for (int k = 0; k < faculties[i]->departments[j]->courses.size(); k++)
                if (strcmp(faculties[i]->departments[j]->courses[k]->code, ccode) == 0) {
                    cr = faculties[i]->departments[j]->courses[k];
                    break;
                }

    if (cr != NULL) cr->showRegistered();
    else cout << "Course not found.\n";
}

// Generate Reports
void University::generateReports() {
    cout << "\n--- Student Timetables ---\n";
    for (list<Student*>::iterator it = students.begin(); it != students.end(); ++it)
        (*it)->showCourses();

    cout << "\n--- Courses ---\n";
    for (int i = 0; i < faculties.size(); i++)
        for (int j = 0; j < faculties[i]->departments.size(); j++)
            for (int k = 0; k < faculties[i]->departments[j]->courses.size(); k++)
                faculties[i]->departments[j]->courses[k]->showRegistered();
}

// GUI Timetable
void University::showTimetableGUI(int studentID) {
    Student* st = NULL;
    for (list<Student*>::iterator it = students.begin(); it != students.end(); ++it)
        if ((*it)->id == studentID) { st = *it; break; }

    if (st == NULL) { cout << "Student not found.\n"; return; }

    cout << "\n--- Timetable for " << st->name << " (ID: " << st->id << ") ---\n";
    cout << "+-----------------+-----------------+\n";
    cout << "| Time Slot       | Course          |\n";
    cout << "+-----------------+-----------------+\n";
    for (list<Course*>::iterator it = st->enrolledCourses.begin(); it != st->enrolledCourses.end(); ++it) {
        Course* c = *it;
        printf("| %-15s | %-15s |\n", c->time, c->name);
        cout << "+-----------------+-----------------+\n";
    }
}

// Save / Load
void University::saveData() {
    ofstream fout("students.txt");
    for (list<Student*>::iterator it = students.begin(); it != students.end(); ++it)
        fout << (*it)->id << " " << (*it)->name << endl;
    fout.close();
}

void University::loadData() {
    ifstream fin("students.txt");
    if (!fin) return;
    int id;
    char name[50];
    while (fin >> id >> name)
        students.push_back(new Student(name, id));
    fin.close();
}

