#include "Department.h"
#include <iostream>
#include <cstring>
using namespace std;

Department::Department(const char* n) {
    strcpy(name, n);
}

void Department::addCourse(Course* c) {
    courses.push_back(c);
}

void Department::showCourses() {
    cout << "\nDepartment: " << name << "\nCourses:\n";
    for (int i = 0; i < courses.size(); i++) {
        cout << " - " << courses[i]->name << " (" << courses[i]->code << ") at " << courses[i]->time << "\n";
    }
}

