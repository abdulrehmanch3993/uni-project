#ifndef FACULTY_H
#define FACULTY_H
#include "Department.h"
#include <vector>
using namespace std;

class Faculty {
public:
    char name[50];
    vector<Department*> departments;

    Faculty(const char* n);
    void addDepartment(Department* d);
    void showDepartments();
};

#endif

