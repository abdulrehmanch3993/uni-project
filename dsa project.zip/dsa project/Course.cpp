#include "Course.h"
#include <iostream>
#include <cstring>
using namespace std;

Course::Course(const char* n, const char* c, int cap, const char* t) {
    maxCapacity = cap;
    strcpy(name, n);
    strcpy(code, c);
    strcpy(time, t);
}

bool Course::addStudent(Student* s) {
    if (registered.size() < maxCapacity) {
        registered.push_back(s);
        return true;
    } else {
        waitingList.push(s);
        return false;
    }
}

void Course::removeStudent(Student* s) {
    for (int i = 0; i < registered.size(); i++) {
        if (registered[i] == s) {
            registered.erase(registered.begin() + i);
            break;
        }
    }
    if (!waitingList.empty()) {
        Student* next = waitingList.front();
        waitingList.pop();
        registered.push_back(next);
    }
}

void Course::showRegistered() {
    cout << "\nCourse: " << name << " (" << code << ") at " << time << "\nRegistered Students:\n";
    if (registered.size() == 0)
        cout << "None\n";
    for (int i = 0; i < registered.size(); i++) {
        cout << " - " << registered[i]->name << " (ID: " << registered[i]->id << ")\n";
    }
    if (!waitingList.empty())
        cout << "Waiting list count: " << waitingList.size() << "\n";
}

